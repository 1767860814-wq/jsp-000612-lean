# JSP-000612: a formal disproof for submission review

This is a reproducible Lean project and evidence package for **review of a
formalization contribution**. It is not an announced award or an officially
completed verification record. The intended recipient remains
`RECIPIENT-JSP-000612-A` pending authorized confirmation.

## Main mathematical result

For every k ≥ 3 and every N, there exists a finite ordinary k-critical graph
G with at least N vertices and a set E of existing edges such that
|E| ≤ binomial(k−1,2) and G−E is two-colorable.

“Critical” quantifies **every proper subgraph**, including edge and vertex
deletions. The genuine extremal minimum over labelled graphs on `Fin n` is
also defined and proved not to tend to infinity, even on admissible orders.
Empty families receive infinity; nonempty minima are attained.

Principal theorem: `JSP612.jsp000612`.
Direct negative answer to the original chromatic-threshold conjecture:
`JSP612.no_chromatic_threshold_for_extremal_divergence`.
Also inspect `JSP612.bounded_attained_minima` and
`JSP612.no_divergence_on_admissible_orders`.

This is a complete disproof of the original divergence assertion. It is not
the separate sharp universal lower bound or the eventual exact formula for
every sufficiently large order. See `submission/SEMANTIC_REVIEW.md` for the
quantifier-by-quantifier correspondence. Historical mathematical priority
is not claimed as a new discovery.

## Pinned source and dependencies

- Source: `JSP000612.lean`, 800 lines, 42 explicit theorem declarations.
- Source SHA-256: `587ea5a73de02a7b8916c7ab79baa1755c027c011551330553bfbba076aaa368`.
- Lean: `leanprover/lean4:v4.19.0`.
- Mathlib: `c44e0c8ee63ca166450922a373c7409c5d26b00b`.
- All dependency revisions are recorded in `lake-manifest.json`.
- No public source URL or first-public timestamp has been created by this
  preparation. The submitter supplies the actual public repository and commit.

## Executed verification

The source was rebuilt with `--trust=0` and warnings treated as errors.
A second clean rebuild ran as UID 1000 with network syscalls denied by a
seccomp filter, a successful EPERM network probe, no-new-privileges, and
resource limits. See `evidence/unprivileged_rebuild.log`.

The theorem dependency closure was replayed into an **empty kernel
environment**: 127 theorem roots including automatically generated lemmas,
and 8,000 transitively needed declarations. Every explicit theorem is among
the replayed roots. Only `propext`, `Classical.choice`, and `Quot.sound` are
allowed axioms. This checks imported proof dependencies rather than merely
trusting their cached status. The underlying kernel is still Lean's kernel;
**this is not an independent implementation**.

A deliberate replacement of the final proof with `True.intro` is rejected by
the kernel, and a custom unproved axiom is rejected by the policy check.
The ordinary compiler controls also cover false arithmetic, `sorry`, and
an altered graph endpoint. The unproved-axiom example deliberately compiles;
compilation alone is not an axiom audit.

A separate Python program checks 16 finite examples using exact coloring
search and exhaustive maximum cuts (115,600 cuts total). These are finite
sanity tests, not a general proof and not an independent Lean checker.

## Reproduce with the supplied offline environment

After restoring the seven-part Lean package already held by the submitter:

```bash
bash verify_offline.sh /absolute/path/Lean419_Offline_linux_x86_64
python3 tools/check_replay.py --offline-root /absolute/path/Lean419_Offline_linux_x86_64
python3 tools/small_graph_check.py
```

The first two commands rebuild the source and exercise dependency replay and
negative controls. They do not download anything. The optional Python finite
test writes `evidence/small_graph_checks.*`; run it in a working copy.

## Standard Lake environment

With elan/Lean and Python 3 available, acquire the pinned dependencies once:

```bash
lake exe cache get
bash verify.sh
```

`verify.sh` rebuilds the main source and runs the replay controls, writing new
results in `reproduction/`. It does not modify the submitted `evidence/` logs.
The standard wrapper was also executed successfully against the restored
dependency directories (`evidence/lake_wrapper_test.log`). The dependency
download itself was not performed in this offline session;
local evidence identifies the restored dependency package actually used.

The invalid files in `tests/` are **intentional negative controls**. They are
not imported by `JSP000612.lean` or the default Lake target. Do not describe
all files in `tests/` as proven theorems.

## Remaining official review

An additional genuinely independent checker implementation has not been run.
Minimum-safe-version certification, independent statement review, public
priority, recipient confirmation, and award eligibility remain pending.
The local adapter and finite tests do not fill those fields. We request
review without fabricating a completed official statement/verification YAML
or external signatures. Official intake permits evidence to remain under
review; acceptance of this mathematical scope is for the curators.

## Submission

Read `提交步骤_CN.md`. Use the five fields in `submission/ISSUE_BODY_EN.md`
for the official **Recommend a recipient** form. Only the actual public
repository URL and 40-character commit SHA must be filled in. Attach the
unchanged evidence ZIP, or provide its public release link. Do not create
multiple duplicate issues or announce a prize/priority determination.

`MANIFEST_SHA256.json` records every delivered file except itself. Run
`python3 tools/verify_manifest.py` before editing or rerunning the package.
