# Execution evidence

`clean_build.log` is a fresh source compilation with Lean 4.19.0, trust 0 and
warnings-as-errors. `unprivileged_rebuild.log` records an additional clean
non-root source build AND complete dependency replay with network syscalls
blocked using libseccomp. The network-denial probe received EPERM. This is
process-level network/resource isolation, not a VM or filesystem sandbox.

`replay_positive.log` and `replay_results.json` record the reusable driver's
transitive dependency replay. `replay_mutation.log` records genuine kernel
rejection of an intentionally wrong proof term, not just a CLI error.
`replay_axiom.log` records rejection of the unproved custom axiom. The checker
source and proof source hashes are in the logs.

`control_results.json` records compiler/axiom-policy controls, including a
case that is expected to compile but must be rejected as an assumed theorem.
`audit_report.json` checks the 42 explicit theorem declarations and their
printed axioms. `small_graph_checks.json` contains actual finite graph
certificates and exhaustive maximum-cut counts; those finite tests are not
a general mathematical proof or an independent Lean kernel implementation.

`input_recheck.json` records the actual restored offline package's seven ZIP
hash checks in this preparation round. The large toolchain/cache binaries
are not redistributed in this submission package.

These logs do not establish independent-checker acceptance, current safe
version status, official statement equivalence, public priority, recipient
confirmation, or an award. See `submission/verification-status.json`.
