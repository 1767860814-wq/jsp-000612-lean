# Lake wrapper reproduction setup

The first attempt to point Lake at the restored dependency directories failed
because Git refused the archive's different-UID-owned checkouts. Lake treated
the unavailable remote URL as a changed remote and attempted a re-clone; the
network-dependent clone failed. That was a setup failure, not a Lean proof
rejection. The affected local Mathlib copy was restored from the original
verified seven-part archive before proceeding.

The final wrapper test supplied **per-process, exact-directory** Git trust
entries for those restored package directories. No global Git configuration
was changed. A normal checkout owned by the reproducing user does not require
that archive-ownership workaround. `verify.sh` does not install a broad Git
trust rule or edit dependency sources.

The dependency source audit checks all nine actual Git revisions against
`lake-manifest.json` and checks tracked contents against those commits.
The reported local changes in Mathlib and Batteries are executable-mode bits
on shell/Python utility files only (32 paths total), not tracked file-content
changes or altered Lean definitions. See `dependency_source_audit.json`.

The standard wrapper uses restored dependency caches; online acquisition was
not executed. Main proof artifacts were rebuilt, and the complete relevant
proof-dependency closure was replayed from an empty kernel environment. This
is not a claim that the entire dependency library was rebuilt from source or
that an independent checker completed verification.
