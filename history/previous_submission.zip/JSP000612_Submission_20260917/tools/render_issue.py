#!/usr/bin/env python3
"""Fill the two public source pins locally. This never publishes or sends data."""
from __future__ import annotations
import argparse
import json
import re
from pathlib import Path
from urllib.parse import urlsplit


def render(repository: str, commit: str, body: str) -> tuple[str, dict[str, str]]:
    u = urlsplit(repository.strip().rstrip('/'))
    if (u.scheme != 'https' or u.netloc != 'github.com' or u.query or u.fragment
            or not re.fullmatch(r'/[A-Za-z0-9-]+/[A-Za-z0-9_.-]+', u.path)):
        raise ValueError('Use a public HTTPS GitHub owner/repository URL, without extra path or query')
    repository = f'https://github.com{u.path}'
    if repository.endswith('.git'):
        repository = repository[:-4]
    if not re.fullmatch(r'[0-9a-fA-F]{40}', commit) or set(commit) == {'0'}:
        raise ValueError('Commit must be a nonzero 40-character hexadecimal Git commit SHA')
    if body.count('PUBLIC_REPOSITORY_URL') != 1 or body.count('PUBLIC_COMMIT_SHA') != 1:
        raise ValueError('Unexpected template; refusing ambiguous replacement')
    result = body.replace('PUBLIC_REPOSITORY_URL', repository).replace('PUBLIC_COMMIT_SHA', commit.lower())
    fields: dict[str, str] = {}
    for match in re.finditer(r'^### ([^\n]+)\n(.*?)(?=^### |\Z)', result, re.M | re.S):
        fields[match.group(1).strip()] = match.group(2).strip()
    expected = ['Related problem or entry', 'Recipient placeholder or confirmed public ID',
                'Contributions and evidence', 'Confirmation status', 'Attribution questions and conflicts']
    if list(fields) != expected or not all(fields.values()):
        raise ValueError('The five official fields were not rendered correctly')
    return result, fields


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repository', required=True)
    p.add_argument('--commit', required=True)
    p.add_argument('--output-dir', type=Path, default=Path('reproduction/submission'))
    a = p.parse_args()
    root = Path(__file__).resolve().parents[1]
    result, fields = render(a.repository, a.commit, (root/'submission/ISSUE_BODY_EN.md').read_text())
    a.output_dir.mkdir(parents=True, exist_ok=True)
    (a.output_dir/'ISSUE_TO_POST.md').write_text(result)
    (a.output_dir/'FORM_FIELDS.json').write_text(json.dumps(fields, indent=2, ensure_ascii=False)+'\n')
    print(f'Written locally to {a.output_dir.resolve()}')
    print('No remote repository/commit lookup, upload, public filing or identity confirmation was performed.')

if __name__ == '__main__':
    main()
