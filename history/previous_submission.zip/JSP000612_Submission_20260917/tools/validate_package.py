#!/usr/bin/env python3
"""Cross-check delivered claims against local execution evidence.

This checks evidence consistency, not mathematical truth or prize eligibility.
"""
from __future__ import annotations
import datetime as dt
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys


def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    evidence = root/'evidence'
    subprocess.run([sys.executable, str(root/'tools/audit.py')], check=True, cwd=root,
                   stdout=subprocess.PIPE, text=True)
    audit = json.loads((evidence/'audit_report.json').read_text())
    replay = json.loads((evidence/'replay_results.json').read_text())
    finite = json.loads((evidence/'small_graph_checks.json').read_text())
    deps = json.loads((evidence/'dependency_source_audit.json').read_text())
    manifest = json.loads((root/'lake-manifest.json').read_text())
    source_hash = sha(root/'JSP000612.lean')
    assert audit['source_sha256'] == replay['source_sha256'] == source_hash
    assert sha(root/'tools/Recheck.lean') == replay['checker_sha256']
    assert audit['theorem_count'] == 42 and audit['source_lines'] == 800
    assert not audit['banned_tokens']
    assert all(x['control_passed'] for x in replay['results'])
    for x in replay['results']:
        assert sha(evidence/f'replay_{x["case"]}.log') == x['log_sha256']
    positive = next(x for x in replay['results'] if x['case'] == 'positive')
    assert positive['explicit_theorems_replayed'] == 42
    assert positive['theorem_roots_including_generated'] == 127
    assert positive['transitive_closure_declarations'] == 8000
    isolation = (evidence/'unprivileged_rebuild.log').read_text()
    for marker in ['ISOLATED_UID: 1000', 'NO_NEW_PRIVILEGES: true',
                   'NETWORK_DENIAL_PROBE: PASS (EPERM)',
                   'FRESH_KERNEL_REPLAY: PASS', 'ISOLATION_COMMAND_EXIT_CODE: 0']:
        assert marker in isolation, marker
    assert 'ROOT_THEOREMS: 127' in isolation and 'CLOSURE_DECLARATIONS: 8000' in isolation
    assert all(x['tracked_file_contents_match_commit'] and x['expected_commit']==x['actual_commit'] for x in deps)
    assert {x['package']: x['actual_commit'] for x in deps} == {x['name']: x['rev'] for x in manifest['packages']}
    assert finite['total_cases'] == 16 and all(x['all_checks_passed'] for x in finite['cases'])
    assert finite['total_cuts_enumerated'] == 115600
    assert finite['script_sha256'] == sha(root/'tools/small_graph_check.py')
    wrapper = (evidence/'lake_wrapper_test.log').read_text()
    assert 'PROJECT_REPRODUCTION: PASS' in wrapper and 'EXIT_CODE: 0' in wrapper
    unittest = (evidence/'submission_tools_tests.log').read_text()
    assert 'Ran 5 tests' in unittest and re.search(r'\bOK\s*$', unittest)
    body = (root/'submission/ISSUE_BODY_EN.md').read_text()
    assert body.count('PUBLIC_REPOSITORY_URL') == 1 and body.count('PUBLIC_COMMIT_SHA') == 1
    assert 'RECIPIENT-JSP-000612-A' in body and 'not a second independent implementation' in body
    result = dict(validated_at_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
                  evidence_consistency='pass', proof_source_sha256=source_hash,
                  explicit_theorems=42, replayed_theorem_roots_including_generated=127,
                  transitive_dependency_declarations=8000,
                  pinned_dependency_repositories=9, exact_finite_examples=16,
                  exhaustive_cuts_in_finite_tests=115600,
                  unprivileged_source_build_and_replay=True,
                  network_syscalls_denied_with_successful_probe=True,
                  standard_lake_wrapper_test='pass with restored dependencies',
                  independent_external_checker_implementations_completed=0,
                  official_verification_complete=False, publicly_submitted=False,
                  award_confirmed=False, validator_sha256=sha(Path(__file__)))
    (evidence/'final_validation.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__ == '__main__':
    main()
