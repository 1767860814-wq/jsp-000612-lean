from pathlib import Path
import argparse
import subprocess, os, json, re, time, resource, hashlib
D=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser(description="Run positive and intentionally invalid Lean controls.")
p.add_argument("lean_root", nargs="?", type=Path, default=Path(os.environ.get("LEAN419_ROOT", "/mnt/data/lean419/Lean419_Offline_linux_x86_64")))
a=p.parse_args()
T=D/'tests'; T.mkdir(exist_ok=True)
R=a.lean_root
env=dict(os.environ)
env['PATH']=str(R/'lean-4.19.0-linux/bin')+':'+env['PATH']
env['LD_LIBRARY_PATH']=str(R/'lean-4.19.0-linux/lib')
env['LEAN_PATH']=':'.join([str(D/'build')]+sorted(str(p) for p in (R/'project/JSP301/.lake/packages').glob('*/.lake/build/lib/lean')))
def limits():
    resource.setrlimit(resource.RLIMIT_CPU,(120,120))
    resource.setrlimit(resource.RLIMIT_AS,(8*1024**3,8*1024**3))
positive='''import JSP000612
open JSP612
example : (0 : ℕ) = 0 := rfl
example : extremalDeletionNumber 4 0 = ⊤ := extremal_infinite_of_order_lt (by decide)
example : ¬ originalExtremalConjecture := originalExtremalConjecture_false
example (N : ℕ) : ∃ n ≥ N, ∃ m : ℕ,
    0 < m ∧ m ≤ 3 ∧ m ∈ attainableCounts 4 n ∧
    extremalDeletionNumber 4 n = (m : ℕ∞) := by
  simpa using bounded_attained_minima 4 (by decide) N
'''
cases=[('Positive.lean',positive,0,[]),
('FalseArithmetic.lean','import JSP000612\nexample : (0 : ℕ) = 1 := by rfl\n',1,[]),
('SorryControl.lean','import JSP000612\ntheorem forbidden_gap : False := by sorry\n#print axioms forbidden_gap\n',1,['sorryAx']),
('AxiomControl.lean','import JSP000612\naxiom test_only_unproved : False\ntheorem test_only_claim : False := test_only_unproved\n#print axioms test_only_claim\n',0,['test_only_unproved'])]
results=[]
for name,src,expected,poison in cases:
    path=T/name; path.write_text(src)
    cmd=['lean','--trust=0','-j2','-DwarningAsError=true',str(path)]
    start=time.monotonic(); p=subprocess.run(cmd,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=130,preexec_fn=limits)
    (D/'evidence'/f'{path.stem}.log').write_text(p.stdout+f'\nEXIT_CODE: {p.returncode}\n')
    passed=p.returncode==expected and all(x in p.stdout for x in poison)
    results.append(dict(name=name,exit_code=p.returncode,expected_exit_code=expected,control_passed=passed,
                        audit_must_reject=bool(poison),forbidden_dependencies=poison,seconds=round(time.monotonic()-start,3)))
    print(name,p.returncode,passed,flush=True)
# A mathematical mutation, generated from the submitted source, is expected to fail.
src=(D/'JSP000612.lean').read_text()
needle='(j.val = 1 ∧ i.val = n)'
assert src.count(needle)==2
mutant=src.replace(needle,'(j.val = 0 ∧ i.val = n)')
path=T/'EndpointMutation.lean';path.write_text(mutant)
start=time.monotonic();p=subprocess.run(['lean','--trust=0','-j2','-DwarningAsError=true',str(path)],env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=130,preexec_fn=limits)
(D/'evidence'/'EndpointMutation.log').write_text(p.stdout+f'\nEXIT_CODE: {p.returncode}\n')
results.append(dict(name=path.name,exit_code=p.returncode,expected_exit_code=1,control_passed=p.returncode==1,
                    mutation='Both far-end blockers changed from color 1 to color 0',seconds=round(time.monotonic()-start,3)))
print(path.name,p.returncode,results[-1]['control_passed'],flush=True)
(D/'evidence'/'control_results.json').write_text(json.dumps(results,indent=2)+'\n')
assert all(x['control_passed'] for x in results)
