#!/usr/bin/env python3
"""Audit only the submitted proof, not the intentionally invalid control files."""
from __future__ import annotations
import argparse
import hashlib
import json
import re
from pathlib import Path

ALLOWED = {'propext', 'Classical.choice', 'Quot.sound'}
BANNED = {'sorry', 'admit', 'axiom', 'native_decide', 'unsafe', 'implemented_by'}

def strip_comments_and_strings(text: str) -> str:
    out: list[str] = []
    i = 0
    depth = 0
    string = False
    while i < len(text):
        if depth:
            if text.startswith('/-', i): depth += 1; i += 2
            elif text.startswith('-/', i): depth -= 1; i += 2
            else:
                if text[i] == '\n': out.append('\n')
                i += 1
        elif string:
            if text[i] == '\\': i += 2
            elif text[i] == '"': string = False; i += 1
            else: i += 1
        elif text.startswith('/-', i): depth = 1; i += 2; out.append(' ')
        elif text.startswith('--', i):
            j = text.find('\n', i)
            i = len(text) if j < 0 else j
        elif text[i] == '"': string = True; i += 1; out.append(' ')
        else: out.append(text[i]); i += 1
    if depth or string:
        raise ValueError('Unterminated comment or string')
    return ''.join(out)

def audit(root: Path) -> dict:
    source = root / 'JSP000612.lean'
    text = source.read_text(encoding='utf-8')
    code = strip_comments_and_strings(text)
    banned = sorted(BANNED.intersection(re.findall(r'[A-Za-z_][A-Za-z_0-9]*', code)))
    names = {'JSP612.' + n for n in re.findall(r'^theorem\s+([A-Za-z0-9_.]+)', code, re.M)}
    logs = {}
    for file in ['clean_build.log', 'unprivileged_rebuild.log']:
        log = (root / 'evidence' / file).read_text()
        dependencies = {n: [a.strip() for a in ax.split(',') if a.strip()]
                        for n, ax in re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]", log)}
        errors = {n: xs for n, xs in dependencies.items() if not set(xs) <= ALLOWED}
        logs[file] = dict(exit_zero='EXIT_CODE: 0' in log, dependencies=dependencies,
                          unexpected_axioms=errors, missing_theorems=sorted(names-set(dependencies)),
                          sha256=hashlib.sha256(log.encode()).hexdigest())
        assert logs[file]['exit_zero'] and not errors and not logs[file]['missing_theorems']
        assert 'error:' not in log
    assert not banned, banned
    assert all(line.startswith('import Mathlib.') for line in code.splitlines() if line.startswith('import '))
    controls = json.loads((root / 'evidence' / 'control_results.json').read_text())
    assert all(c['control_passed'] for c in controls)
    result = dict(source=source.name, source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                  source_lines=len(text.splitlines()), theorem_count=len(names), banned_tokens=banned,
                  all_theorems_audited=True, allowed_foundational_axioms=sorted(ALLOWED), logs=logs,
                  controls=controls, independent_checker_count_completed=0,
                  scope='Disproof of the original divergence conjecture, not the sharp eventual equality theorem',
                  award_confirmed=False, publicly_submitted=False)
    return result

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('root', nargs='?', type=Path, default=Path(__file__).resolve().parents[1])
    a = p.parse_args()
    result = audit(a.root)
    output = a.root / 'evidence' / 'audit_report.json'
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['source_sha256', 'source_lines', 'theorem_count',
          'banned_tokens', 'all_theorems_audited', 'independent_checker_count_completed',
          'award_confirmed']}, indent=2))
