# JSP-000612：提交给官方审查

**这个包现在用于“形式化贡献审查申请”，不是已经批准的领奖材料。**
数学源代码及本地证据已整理好。独立检查器、版本安全、题目范围、首发优先权和获奖资格仍须实际审查；不要把 pending 改成“已通过”。

## 你实际要做的三步

### 1. 把完整工程公开到你控制的 GitHub 仓库

新建一个公开仓库，例如 `jsp-000612-lean`。解压本 ZIP，将工程目录里的文件和子文件夹上传到仓库根目录；不要只上传压缩包。
根目录应直接看到 `JSP000612.lean`、`lakefile.lean`、`lean-toolchain`、`lake-manifest.json`、`README.md`，以及 `tools/`、`tests/`、`evidence/`、`submission/`。

公开前检查许可和你 GitHub 个人资料、提交记录会展示的信息。申请正文继续保留 `RECIPIENT-JSP-000612-A`，不要自行填入未确认的获奖人身份。

记录公开仓库网址，以及这次上传对应的完整 **40 位 commit SHA**。不要把源文件的 64 位 SHA-256 当作 commit SHA；也不要只填 `main`。

### 2. 填两项公开信息

打开 `submission/ISSUE_BODY_EN.md`，只替换：

- `PUBLIC_REPOSITORY_URL`：你刚公开的仓库网址。
- `PUBLIC_COMMIT_SHA`：对应的 40 位完整 commit。

其余技术内容、历史归属和待审状态不需要改。无需提供邮箱、护照、银行账户或钱包地址。
熟悉命令行时也可运行 `tools/render_issue.py` 自动生成填好字段的正文；该工具不会上传或发帖。

### 3. 到官方仓库提交一次 Recipient 申请

官方入口：
https://github.com/TheJustinSunPrize/awards/issues/new?template=recommend-recipient.yml

选择 **Recommend a recipient**。标题使用 `submission/ISSUE_TITLE.txt`。
正文已经按官方表单的五个栏目写好：把每个标题下的内容分别贴进对应栏目，而不是把五栏全部塞进第一格。
附上未改动的 `JSP000612_Submission_20260917.zip`，或你的公开 Release 中该 ZIP 的链接。主源码已公开，ZIP 是完整复核证据补充。

发之前在官方 Issues / Pull requests 搜索 `JSP-000612`、`000612`、`Erdos744`。已存在同一项目的申请就补充原帖；发现别人的相关申请就如实交叉引用，不要写“确定没人申请”。这次检索未能完成穷尽优先权核查。

## 不需要你再做的事

不需要你重写证明，也不需要你把几 GB 的 Lean 环境重新上传到 GitHub。
本包只包含本题工程、测试和证据。正常读者可用固定依赖复现；有现成七包环境的读者也可离线复现。

## 已实际完成与未完成

已完成：42 个显式定理的源码编译、公理审计、非 root 且网络系统调用受限的重编译、空内核环境中的 8,000 项传递依赖重检，以及无效证明/自定义公理拒绝测试。还有 16 个有限图的精确独立 Python 检查。

未完成：另一种独立 Lean 检查器实现的验证、官方安全版本认证、独立签署的命题对应审查、首次公开优先权认定、身份确认及奖金决定。同内核重检和有限图测试不能冒充这些结果。

这份证明否定原始“删边数随规模发散”的猜想；它不声称补齐 Rödl–Tuza 的全部最优下界和每个大规模的精确公式。正文已直接请求官方判断这个完整否定答案是否符合 612 的受理范围。

## 官方依据

表单与字段：
https://raw.githubusercontent.com/TheJustinSunPrize/awards/main/.github/ISSUE_TEMPLATE/recommend-recipient.yml

提交/隐私规范：
https://raw.githubusercontent.com/TheJustinSunPrize/awards/main/CONTRIBUTING.md

待审材料与完成验证的区别：
https://raw.githubusercontent.com/TheJustinSunPrize/awards/main/docs/records.md

**提交后保存 Issue 地址和公开源码的 commit。提交本身不等于认可首发或确认获奖。**
