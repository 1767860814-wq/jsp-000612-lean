# Outstanding substantive review requests

These are requests, not certifications. They do not invalidate the locally
checked mathematical result, but they prevent treating this package as an
already completed official verification/award record.

1. Inspect the exact Lean predicates and original quantifiers. Decide whether
   the negative answer to the original divergence conjecture is the intended
   JSP-000612 scope, rather than the stronger later sharp equality.
2. Run a genuinely independent checker implementation against pinned proof
   source and the necessary dependency closure; record actual release/version,
   configuration, axioms, logs, artifact hashes and outcome. The included
   same-kernel replay is not a substitute. No nanoda/Lean4Lean result is claimed.
3. Determine applicable minimum-safe Lean/library/checker versions. The
   locally exercised version is 4.19.0, not asserted to be the current release.
4. Establish public priority using dated public sources rather than the local
   archive date or a claim that nobody else has applied.
5. Obtain authorized recipient confirmation and reviewer signatures through
   the official process. Keep private documents out of public source history.

The official verification/statement YAML should be created or completed only
with real evidence and authorized signatories. We deliberately supply a local
status report, not a falsely complete live candidate/award record.

Sources:
https://raw.githubusercontent.com/TheJustinSunPrize/awards/main/docs/records.md
https://raw.githubusercontent.com/TheJustinSunPrize/awards/main/docs/verification.md
https://raw.githubusercontent.com/TheJustinSunPrize/awards/main/docs/attribution.md
