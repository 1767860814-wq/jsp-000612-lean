### Related problem or entry

JSP-000612 — How many edges must be deleted from a chromatic-critical graph to make it bipartite?

### Recipient placeholder or confirmed public ID

RECIPIENT-JSP-000612-A

### Contributions and evidence

Please review this AI-assisted Lean formalization for recognition of a formalization contribution to JSP-000612, subject to the required scope, verification, priority and attribution review.

Public proof repository: PUBLIC_REPOSITORY_URL
Pinned 40-character commit: PUBLIC_COMMIT_SHA
Main source file at that commit: `JSP000612.lean`
Source SHA-256: `587ea5a73de02a7b8916c7ab79baa1755c027c011551330553bfbba076aaa368`
Evidence: the attached `JSP000612_Submission_20260917.zip`, with its file manifest and execution logs.

**Proved result.** For every k≥3 and every N, a finite ordinary k-critical graph exists with at least N vertices and becomes two-colorable after deleting at most binomial(k−1,2) of its existing edges. Criticality quantifies every proper subgraph, including edge and vertex deletions. A genuine extremal function is defined by minimizing attainable deletion counts over graphs on `Fin n`; nonempty minima are attained, empty families are infinite, and no expected answer is encoded in that definition. The function does not tend to infinity, even when the limit is restricted to admissible orders. An existential threshold on k does not rescue the conjecture.

Main declarations: `JSP612.jsp000612`, `JSP612.bounded_attained_minima`, `JSP612.no_chromatic_threshold_for_extremal_divergence`, `JSP612.originalExtremalConjecture_false`, and `JSP612.no_divergence_on_admissible_orders`.

The exact original-question correspondence is in `submission/SEMANTIC_REVIEW.md`; the mathematical construction is explained in `PROOF_EN.md`. The original question is on page 15 of https://www.renyi.hu/~p_erdos/1981-16.pdf .

**Executed checks.** Lean 4.19.0 / Mathlib `c44e0c8ee63ca166450922a373c7409c5d26b00b`. The 800-line source contains 42 explicit theorems, with no `sorry`, `admit`, or custom axiom declaration. Source rebuilds used `--trust=0` and warnings-as-errors. A clean non-root run used process-level network-syscall blocking, a successful denial probe, no-new-privileges and resource limits. Complete transitive dependency replay from an empty environment passed: 127 theorem roots including generated lemmas and 8,000 declarations. Only `propext`, `Classical.choice`, and `Quot.sound` occur as axioms. An intentionally substituted invalid proof and an unproved axiom were rejected. Logs and runnable scripts are included.

The replay uses the same Lean kernel and **is not a second independent implementation**. The additional 16 exact finite graph tests are only sanity checks. Independent external checking, safe-version certification and signed semantic review remain pending. The offline reproduction route was executed; the package states separately which online dependency-acquisition steps were not executed here.

**Requested handling.** Please review the original-conjecture disproof and the proposed formalization contribution, arrange/identify the outstanding verification, and assess whether any catalogue or eligibility change is warranted. This submission does not unilaterally change `Lean proof`, `Eligible to claim`, or an award status. No completed official verification record or reviewer signature is fabricated.

### Confirmation status

Pending. The recipient identity remains a placeholder. No unconfirmed identity, private contact information, identity document, payment detail or public attestation is included. Public source publication and this filing do not themselves constitute written recipient confirmation.

### Attribution questions and conflicts

The historical mathematical negative answer is credited to the established literature, particularly Rödl and Tuza (1985); no new-mathematics discovery credit is requested for rediscovering it. This recommendation concerns the AI-assisted formalization and its verification materials. It is a submission seeking recognition for the submitting project, not an independent referee report.

Cross-platform first-public-formalization priority has not been adjudicated. Please compare dated public sources and any existing related issues. This package does not prove the sharp universal lower bound or the eventual exact formula for every sufficiently large order; acceptance of the original-question scope is expressly requested rather than assumed. Additional attribution or public conflict disclosures, if required, must come from the submitter and the reviewers, not from invented statements in this package.
