# Deliberate controls (not submission dependencies)

Positive.lean must pass. FalseArithmetic.lean, SorryControl.lean and
EndpointMutation.lean must fail. The last changes the far endpoint blocker
from color 1 to color 0 in both symmetric adjacency clauses.
AxiomControl.lean compiles, but its printed dependency test_only_unproved is
not an allowed foundational axiom, so an acceptance audit must reject it.
The submitted JSP000612.lean imports none of these files.
