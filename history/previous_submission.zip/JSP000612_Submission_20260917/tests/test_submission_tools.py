"""Local publication-template tests. Synthetic URLs are not publication claims."""
import importlib.util
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('renderer', ROOT/'tools/render_issue.py')
renderer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(renderer)

class SubmissionTools(unittest.TestCase):
    def setUp(self):
        self.body = (ROOT/'submission/ISSUE_BODY_EN.md').read_text()
    def test_valid_fields(self):
        body, fields = renderer.render('https://github.com/example-account/example-repository', 'a1'*20, self.body)
        self.assertEqual(len(fields), 5)
        self.assertNotIn('PUBLIC_REPOSITORY_URL', body)
        self.assertNotIn('PUBLIC_COMMIT_SHA', body)
        self.assertIn('Pending.', fields['Confirmation status'])
        self.assertIn('not a second independent implementation', body)
    def test_reject_sha256_instead_of_commit(self):
        with self.assertRaises(ValueError):
            renderer.render('https://github.com/example-account/example-repository', 'a1'*32, self.body)
    def test_reject_private_or_credential_url(self):
        with self.assertRaises(ValueError):
            renderer.render('https://secret@github.com/example-account/example-repository', 'a1'*20, self.body)
    def test_reject_missing_pin(self):
        with self.assertRaises(ValueError):
            renderer.render('https://github.com/example-account/example-repository', 'main', self.body)
    def test_reject_ambiguous_template(self):
        with self.assertRaises(ValueError):
            renderer.render('https://github.com/example-account/example-repository', 'a1'*20, self.body+' PUBLIC_COMMIT_SHA')

if __name__ == '__main__':
    unittest.main()
